angular
.module('app')
.component('quiz', {
    templateUrl: "components/quiz/quiz.html",
    controller: "QuizController",
    controllerAs: "controller",
})
.controller('QuizController', function(QuizFactory) {
    this.QuizFactory = QuizFactory;
    console.log("Here", QuizFactory);
})
.factory('QuizFactory', function(){
    var QuizFactory = this;
    QuizFactory.current = 0;
    QuizFactory.question = "";
    QuizFactory.button = "";
    QuizFactory.answer = "";
    QuizFactory.end = false;

    QuizFactory.questions = [
      {"question":"What is your gender?"},
      {"question":"Do you currently have an active account on Facebook, Instagram, and/or Twitter?"},
		{"question": "Are you willing to answer surveys and share your opinions in exchange for gifts?"}
    ];
	
	QuizFactory.buttons = [
      {"button":"Male"},
      {"button":"Female"},
      {"button":"Yes"},
      {"button":"No"},
      {"button":"Yes"},
      {"button":"No"}
		
    ];

    QuizFactory.answers = [];

    QuizFactory.getQuestion = function()
    {
        if(QuizFactory.button)
        {
          QuizFactory.buttons.push(QuizFactory.button);
          QuizFactory.button = "";
        }

        if(QuizFactory.current < QuizFactory.questions.length)
        {
          var question = QuizFactory.questions[QuizFactory.current].question;
          QuizFactory.current++;
          QuizFactory.question = question;
        } else {
          QuizFactory.end = true;
        }
    }

    QuizFactory.getQuestion();

    return QuizFactory;
})
