'use strict';

angular
.module('app', ['ui.router'])
.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider
  .state({
    name: 'quiz',
    url: 'components',
    templateUrl: 'components/quiz/quiz.html',
    controller: 'QuizController',
    controllerAs: "controller"
  });

  $urlRouterProvider.otherwise("quiz");
});
